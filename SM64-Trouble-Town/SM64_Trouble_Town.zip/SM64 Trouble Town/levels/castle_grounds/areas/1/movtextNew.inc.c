const struct MovtexQuadCollection castle_grounds_1_Movtex_0[] = {
{-1, NULL},
};
const struct MovtexQuadCollection castle_grounds_1_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection castle_grounds_1_Movtex_2[] = {
{-1, NULL},
};
