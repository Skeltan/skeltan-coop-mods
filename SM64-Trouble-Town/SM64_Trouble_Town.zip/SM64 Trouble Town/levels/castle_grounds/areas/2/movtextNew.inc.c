const struct MovtexQuadCollection castle_grounds_2_Movtex_0[] = {
{-1, NULL},
};
const struct MovtexQuadCollection castle_grounds_2_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection castle_grounds_2_Movtex_2[] = {
{-1, NULL},
};
