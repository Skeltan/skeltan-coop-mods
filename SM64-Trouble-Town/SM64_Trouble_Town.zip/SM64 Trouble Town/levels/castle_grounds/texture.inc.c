ALIGNED8 u8 castle_grounds_1__texture_0E000018[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E000820[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E001020[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E001820[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E002020[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E003020[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E003A20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe003a20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E004220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe004220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E005220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe005220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E007220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe007220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E007A20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe007a20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E010A20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe010a20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E008A20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe008a20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E009220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe009220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E009A20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe009a20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00AA20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00aa20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E010220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe010220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00B220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00b220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00BA20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00ba20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00C220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00c220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00CA20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00ca20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00D220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00d220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E011A20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe011a20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00DA20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00da20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00FA20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00fa20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00EA20[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00ea20_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E00E220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe00e220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E002820[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E003220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe003220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E006220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe006220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_1__texture_0E011220[] = {
#include "levels/castle_grounds/castle_grounds_1_0xe011220_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E000018[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E002820[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E003020[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E003820[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E002020[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E001020[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E004820[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E004020[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe004020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E001820[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_2__texture_0E000820[] = {
#include "levels/castle_grounds/castle_grounds_2_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E000018[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E003020[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E003820[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E002820[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E001020[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E002020[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 castle_grounds_3__texture_0E000820[] = {
#include "levels/castle_grounds/castle_grounds_3_0xe000820_custom.rgba16.inc.c"
};
