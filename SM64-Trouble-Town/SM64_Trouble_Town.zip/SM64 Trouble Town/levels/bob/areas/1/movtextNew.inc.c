static Movtex bob_1_Movtex_0_0[] = {1, 0, 15, 16, -12000, -12000, 12000, -12000, 12000, 12000, -12000, 12000, 1, 79, 0, 0};

static Movtex bob_1_Movtex_0_2[] = {1, 0, 15, 16, -12000, -12000, 12000, -12000, 12000, 12000, -12000, 12000, 1, 79, 0, 0};

const struct MovtexQuadCollection bob_1_Movtex_0[] = {
{0,bob_1_Movtex_0_0},
{-1, NULL},
};
const struct MovtexQuadCollection bob_1_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection bob_1_Movtex_2[] = {
{0,bob_1_Movtex_0_2},
{-1, NULL},
};
