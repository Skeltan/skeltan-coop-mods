ALIGNED8 u8 bob_1__texture_0E000018[] = {
#include "levels/bob/bob_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E000820[] = {
#include "levels/bob/bob_1_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001020[] = {
#include "levels/bob/bob_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E001820[] = {
#include "levels/bob/bob_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002020[] = {
#include "levels/bob/bob_1_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E006020[] = {
#include "levels/bob/bob_1_0xe006020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E002820[] = {
#include "levels/bob/bob_1_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E003020[] = {
#include "levels/bob/bob_1_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E003820[] = {
#include "levels/bob/bob_1_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E004020[] = {
#include "levels/bob/bob_1_0xe004020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E004820[] = {
#include "levels/bob/bob_1_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E005020[] = {
#include "levels/bob/bob_1_0xe005020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E005820[] = {
#include "levels/bob/bob_1_0xe005820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E006820[] = {
#include "levels/bob/bob_1_0xe006820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E007820[] = {
#include "levels/bob/bob_1_0xe007820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E008020[] = {
#include "levels/bob/bob_1_0xe008020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E008820[] = {
#include "levels/bob/bob_1_0xe008820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00B820[] = {
#include "levels/bob/bob_1_0xe00b820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E009020[] = {
#include "levels/bob/bob_1_0xe009020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E009820[] = {
#include "levels/bob/bob_1_0xe009820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00B020[] = {
#include "levels/bob/bob_1_0xe00b020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00BC20[] = {
#include "levels/bob/bob_1_0xe00bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00A020[] = {
#include "levels/bob/bob_1_0xe00a020_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00A820[] = {
#include "levels/bob/bob_1_0xe00a820_custom.rgba16.inc.c"
};
ALIGNED8 u8 bob_1__texture_0E00C420[] = {
#include "levels/bob/bob_1_0xe00c420_custom.rgba16.inc.c"
};
