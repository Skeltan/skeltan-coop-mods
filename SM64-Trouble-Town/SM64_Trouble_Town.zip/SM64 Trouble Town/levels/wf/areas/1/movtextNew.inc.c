static Movtex wf_1_Movtex_0_0[] = {1, 0, 15, 16, -17000, -17000, -1000, -17000, -1000, -1000, -17000, -1000, 1, 79, 0, 0};

const struct MovtexQuadCollection wf_1_Movtex_0[] = {
{0,wf_1_Movtex_0_0},
{-1, NULL},
};
const struct MovtexQuadCollection wf_1_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection wf_1_Movtex_2[] = {
{-1, NULL},
};
