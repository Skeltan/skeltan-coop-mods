ALIGNED8 u8 cotmc_1__texture_0E000018[] = {
#include "levels/cotmc/cotmc_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 cotmc_1__texture_0E001820[] = {
#include "levels/cotmc/cotmc_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 cotmc_1__texture_0E001020[] = {
#include "levels/cotmc/cotmc_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 cotmc_1__texture_0E000820[] = {
#include "levels/cotmc/cotmc_1_0xe000820_custom.rgba16.inc.c"
};
