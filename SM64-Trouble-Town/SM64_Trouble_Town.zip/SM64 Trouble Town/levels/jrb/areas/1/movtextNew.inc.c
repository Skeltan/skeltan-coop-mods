static Movtex jrb_1_Movtex_0_0[] = {1, 0, 15, 16, -10000, -10000, 10000, -10000, 10000, 10000, -10000, 10000, 1, 79, 0, 0};

const struct MovtexQuadCollection jrb_1_Movtex_0[] = {
{0,jrb_1_Movtex_0_0},
{-1, NULL},
};
const struct MovtexQuadCollection jrb_1_Movtex_1[] = {
{-1, NULL},
};
const struct MovtexQuadCollection jrb_1_Movtex_2[] = {
{-1, NULL},
};
