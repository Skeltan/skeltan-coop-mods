// 0x07011370 - 0x0701137C
const MacroObject jrb_seg7_area_2_macro_objs[] = {
    MACRO_OBJECT(/*preset*/ macro_box_star_1, /*yaw*/   0, /*pos*/ 0,  1600,  3000),
    MACRO_OBJECT_END(),
};
