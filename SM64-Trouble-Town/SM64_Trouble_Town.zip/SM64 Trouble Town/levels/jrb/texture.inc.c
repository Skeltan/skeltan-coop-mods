ALIGNED8 u8 jrb_1__texture_0E000018[] = {
#include "levels/jrb/jrb_1_0xe000018_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00D420[] = {
#include "levels/jrb/jrb_1_0xe00d420_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E000820[] = {
#include "levels/jrb/jrb_1_0xe000820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E001020[] = {
#include "levels/jrb/jrb_1_0xe001020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E001820[] = {
#include "levels/jrb/jrb_1_0xe001820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E002020[] = {
#include "levels/jrb/jrb_1_0xe002020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E002820[] = {
#include "levels/jrb/jrb_1_0xe002820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E003020[] = {
#include "levels/jrb/jrb_1_0xe003020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E003820[] = {
#include "levels/jrb/jrb_1_0xe003820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E011620[] = {
#include "levels/jrb/jrb_1_0xe011620_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E004820[] = {
#include "levels/jrb/jrb_1_0xe004820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E005020[] = {
#include "levels/jrb/jrb_1_0xe005020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E005820[] = {
#include "levels/jrb/jrb_1_0xe005820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E006020[] = {
#include "levels/jrb/jrb_1_0xe006020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E006820[] = {
#include "levels/jrb/jrb_1_0xe006820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E007020[] = {
#include "levels/jrb/jrb_1_0xe007020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E007820[] = {
#include "levels/jrb/jrb_1_0xe007820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E008820[] = {
#include "levels/jrb/jrb_1_0xe008820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E009020[] = {
#include "levels/jrb/jrb_1_0xe009020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E009820[] = {
#include "levels/jrb/jrb_1_0xe009820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00A020[] = {
#include "levels/jrb/jrb_1_0xe00a020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00A820[] = {
#include "levels/jrb/jrb_1_0xe00a820_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00B020[] = {
#include "levels/jrb/jrb_1_0xe00b020_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00B420[] = {
#include "levels/jrb/jrb_1_0xe00b420_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00BC20[] = {
#include "levels/jrb/jrb_1_0xe00bc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00C420[] = {
#include "levels/jrb/jrb_1_0xe00c420_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00CC20[] = {
#include "levels/jrb/jrb_1_0xe00cc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E010E20[] = {
#include "levels/jrb/jrb_1_0xe010e20_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E010C20[] = {
#include "levels/jrb/jrb_1_0xe010c20_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00DC20[] = {
#include "levels/jrb/jrb_1_0xe00dc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00E420[] = {
#include "levels/jrb/jrb_1_0xe00e420_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00FC20[] = {
#include "levels/jrb/jrb_1_0xe00fc20_custom.rgba16.inc.c"
};
ALIGNED8 u8 jrb_1__texture_0E00EC20[] = {
#include "levels/jrb/jrb_1_0xe00ec20_custom.rgba16.inc.c"
};
