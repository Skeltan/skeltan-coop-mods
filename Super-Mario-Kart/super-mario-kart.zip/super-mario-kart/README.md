# Super Mario Kart Ex Coop
Basically Super Mario Kart in SM64 Ex Coop

At this point, only 3 maps will be added but I'm open to add more if i find a way to add more races

Tracks :

- Mario Circuit 2
- Bowser's Castle 2
- Rainbow Road
